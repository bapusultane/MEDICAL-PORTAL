package com.medicare.respository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.medicare.model.Temp;



public interface TempRepository extends JpaRepository<Temp, Integer> {

	
	@Query(value = "SELECT `pid`  FROM `temp` GROUP by `pid` ORDER by  count(`pid`) DESC LIMIT 7", nativeQuery = true)
	List<?> getAllRecentDesc();
	
}
