package com.medicare.respository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.medicare.model.Category;
import com.medicare.model.Product;

public interface CategoryRepository  extends JpaRepository <Category , Integer>{


	//query to get category by catid 
	@Query(value = "SELECT * FROM category WHERE catid=:catid", nativeQuery = true)
	Category getCategoryById(@Param("catid") Integer catid);


	@Query(value = "SELECT * FROM category WHERE catid=:catid", nativeQuery = true)
	Category getCategoriesById(@Param("catid") Integer catid);

	//query to get category by name 
	@Query(value = "SELECT * FROM category WHERE category=:category", nativeQuery = true)
	Category fetchCategoryByName(@Param("category") String category);

	//query to find category by name  
	@Query(value = "SELECT * FROM category WHERE category=:category", nativeQuery = true)
	Category findbyCategory(@Param("category") String category);


	@Query(value = "SELECT * FROM category WHERE catid=:catid", nativeQuery = true)
	Category findbyCategory1(@Param("catid") Category category);
	
	
	
	@Query(value="SELECT * FROM category where catid=:catid",nativeQuery = true)
	Category findCategoryByCatId(@Param("catid") Category category);
	

}
