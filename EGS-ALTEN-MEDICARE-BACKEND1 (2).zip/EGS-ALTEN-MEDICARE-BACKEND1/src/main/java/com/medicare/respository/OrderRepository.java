package com.medicare.respository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.Temp;

public interface OrderRepository extends JpaRepository <Orders, Integer>{
	//query to get Orders by id 
	@Query(value = "SELECT * FROM Orders WHERE id=:id", nativeQuery = true)
	Orders getById(@Param("id") Integer id);

	//query to get Orders by id 
	@Query(value = "SELECT * FROM Orders WHERE id=:id", nativeQuery = true)
	Orders getStatusById(@Param("id") Integer id);

	@Query(value = "SELECT * FROM Orders WHERE id=:id", nativeQuery = true)
	Orders getOrdersById(@Param("id") Integer id);
	//query to get Orders list 
	@Query(value = "SELECT *FROM Orders ORDER BY orders id=:id DESC", nativeQuery = true)
	List<Orders> orderlist();

	//query to get Orders list as descending order  
	@Query(value = "SELECT * FROM `orders`  \r\n"
			+ "ORDER BY `orders`.`id` DESC", nativeQuery = true)
	List<Orders> getAllOrdersDesc();
	//get all user list by id 
	@Query(value="SELECT * FROM orders WHERE userid=:userid",nativeQuery=true)
	List<Orders> getAllOrderListByUserId(@Param("userid") Integer userid);


	@Query(value="SELECT * FROM orders WHERE status=:status",nativeQuery=true)
	List<Orders> findByIdCpfk(@Param ("status") Integer status);

	//list of orders by status id 
	@Query(value="SELECT * FROM orders WHERE status_id=:id",nativeQuery=true)
	List<Orders> findByIdStatusId(@Param ("id") Integer id);




}
