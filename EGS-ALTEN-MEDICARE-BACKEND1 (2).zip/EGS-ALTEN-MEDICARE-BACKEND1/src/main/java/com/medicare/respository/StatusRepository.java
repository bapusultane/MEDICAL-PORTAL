package com.medicare.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.medicare.model.Status;

public interface StatusRepository extends JpaRepository<Status, Integer>  {

}
