package com.medicare.respository;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.medicare.model.Category;
import com.medicare.model.Product;

import jakarta.transaction.Transactional;

public interface ProductRepository extends JpaRepository <Product, Integer>  {
	
	
	@Query(value = "SELECT * FROM Product WHERE id=:id", nativeQuery = true)
	public Product getProductDetailsById(@Param("id") Integer id);

	@Query(value = "SELECT *FROM Product WHERE price=:price", nativeQuery = true)
	public Product getProductDetailsByPrice(@Param("price") Integer price);

	@Query(value = "SELECT *FROM Product WHERE price=:price ORDER BY price ASC", nativeQuery = true)
	public Product getproductDetailsBypriceAsc(@Param("price") Integer price);

	@Query(value = "SELECT *FROM Product WHERE price=:price ORDER BY price DSC", nativeQuery = true)
	public Product getproductDetailsBypriceDsc(@Param("price")Integer price);


	@Query(value = "SELECT * FROM Products WHERE pid=:pid", nativeQuery = true)
	public Product getProductById(@Param("pid") Integer pid);
	

	@Query(value = "SELECT * FROM Products WHERE category=:category", nativeQuery = true)
	public Product productsByName(@Param("category") String category);

	@Query(value = "SELECT * FROM Products WHERE category_catid=:catid", nativeQuery = true)
	public List<Product> getAllProductByCategory(@Param("catid") Integer catid);

	@Query(value = "SELECT * FROM Products WHERE name=:name", nativeQuery = true)
	public List<Product> getAllProductByName(@Param("name") String name);

	@Query(value = "SELECT * FROM Products WHERE status=:status", nativeQuery = true)
	public List<Product> disable(@Param("status") Integer status);

	@Query(value = "SELECT * FROM Products WHERE name=:name", nativeQuery = true)
	public Product findProductByName(@Param("name") String productName);

	@Query(value="UPDATE products \r\n"
			+ "   SET category=(SELECT category FROM category WHERE products.catid=category.catid);",nativeQuery=true)
	public Product updateProductById(@Param("catid") Integer catid);

	
	@Query(value = "SELECT * FROM Products WHERE catid=:catid", nativeQuery = true)
	public List<Product>
	getByCatId(@Param("catid") Integer catid);

	@Query(value = "UPDATE products \r\n"
			+ "   SET category=(SELECT category FROM category WHERE products.catid=category.catid)", nativeQuery = true)
	public Product updateProduct1(Product p);


	@Query(value = "UPDATE products \r\n"
			+ "   SET category=(SELECT category FROM category WHERE products.catid=category.catid)", nativeQuery = true)
	public Product updateProductBycatid();

	
	@Query(value = "SELECT * FROM Products WHERE cp_fk=:cp_fk", nativeQuery = true)
	public List <Product> findByIdCpfk(@Param("cp_fk") Integer cp_fk);

	
	
	
	@Query(value = "SELECT * FROM Products WHERE category_catid=:catid", nativeQuery = true)
	public List<?> getAllProductByCategory1(@Param ("catid") Integer catid);

	
	
	



}
