package com.medicare.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.medicare.model.Role;

public interface RoleRepository extends JpaRepository <Role, Integer> {


	
	@Query(value = "SELECT * FROM Roles WHERE rolename=:roleName", nativeQuery = true)
	Role fetchUserByRole(@Param("roleName") String roleName);
	

	@Query(value="SELECT * FROM roles where rolename=:rolename",nativeQuery = true)
	Role findByName(@Param("rolename") String rolename);

	@Query(value="SELECT * FROM roles where roleid=:roleid",nativeQuery = true)
    Role findRoleById(@Param ("roleid") Integer roleid);


}
