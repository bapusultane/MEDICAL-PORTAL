package com.medicare.controller;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity.BodyBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.medicare.model.Category;
import com.medicare.model.Product;
import com.medicare.model.User;
import com.medicare.respository.ProductRepository;
import com.medicare.service.CategoryService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/category/")
public class CategoryController {

	@Autowired 
	CategoryService  categoryService;




	//add new category
	@PostMapping("/add")
	public ResponseEntity<Category> addCategory(@RequestBody Category category){

		String categoryName = category.getCategory();
		if(categoryName != null && !"".equals(categoryName)) {
			Category cateObj = categoryService.fetchCategoryByName(categoryName);
			if(cateObj != null) {
				return new ResponseEntity<Category>(HttpStatus.BAD_REQUEST);
			}
		}

		return categoryService.addCategory(category);
	}
	//update category by category id 
	@PutMapping("/categories/{catid}")
	public ResponseEntity<Category> updateCategorys(@PathVariable Integer catid, @RequestBody Product product) {
		Category cat = categoryService.udpateCategory(catid,product);
		return ResponseEntity.ok(cat);
	}

	//update category 
	@PutMapping("/update")  
	private Category updatecategory(@RequestBody Category category)   
	{  
		categoryService.save(category);
		return category;  
	}  
	//update category by category id 
	@PutMapping("/category/{catid}")
	public ResponseEntity<Category> updateCategory(@PathVariable Integer catid, @RequestBody Category category) {
		Category cat = categoryService.getCategoryById(catid);

		cat.setCategory(category.getCategory());
		cat.setImageurl(category.getImageurl());

		Category updateCategory = categoryService.save(cat);
		return ResponseEntity.ok(updateCategory);



	}


	//find category by id 
	@GetMapping("/categorys/{catid}")  
	private Category getCategoriesById(@PathVariable("catid") Integer catid)   
	{  
		return categoryService.getCategoriesById(catid); 
	}  
	//Get category list 
	@GetMapping("/categorylist")  
	private List<Category> getAllCategory()   

	{  
		return categoryService.getAllCategory();  
	}  
	//delete category by id 
	@DeleteMapping("/category/{catid}")  
	private void deleteCategory(@PathVariable("catid") Integer catid)   
	{  
		categoryService.delete(catid); 
	} 

}

