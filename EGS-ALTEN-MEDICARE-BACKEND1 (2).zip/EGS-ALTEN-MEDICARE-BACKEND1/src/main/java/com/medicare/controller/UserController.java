package com.medicare.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.medicare.model.Contact;
import com.medicare.model.Product;
import com.medicare.model.Role;
import com.medicare.model.User;
import com.medicare.respository.RoleRepository;
import com.medicare.service.UserService;


@RestController 
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/user/")
public class UserController {


	@Autowired 
	UserService userService;

	@Autowired 
	RoleRepository roleRepository;

	

	//user registration  
	@PostMapping("/signup")
	public User signUp(@RequestBody User user) throws Exception{
		System.out.println("welcome to product controller ");
		String emailId = user.getEmailid();
		if(emailId != null && !"".equals(emailId)) {
			User userobj = userService.fetchUserByEmailId(emailId);
			if(userobj != null) {
				throw new Exception(emailId+" is already exist");
			}
		}

		return userService.register(user);

	}
	//user login 
	@PostMapping("/login")
	public ResponseEntity<User> login(@RequestBody User user) {
		String emailId = user.getEmailid();
		String password = user.getPassword();


		User userObj = null;

		if(emailId != null && password != null) {

			userObj = userService.fetchUsersByEmailAndPasswordAndRole(emailId, password);

		}

		String emailId2 = userObj.getEmailid();

		String password2 = userObj.getPassword();


		if(emailId.equals(emailId2) && password.equals(password2)) {
			System.out.println(userObj);
			return ResponseEntity.ok(userObj);

		}else
		{
			return new ResponseEntity<User>(HttpStatus.BAD_REQUEST);
			
			
		}
	}
	//forgot password api 
	@PutMapping("/user/{emailid}")
	public ResponseEntity<?> updateUsers(@PathVariable String emailid, @RequestBody User user) {
		User u = userService.getUserByemailId(emailid);
		String password1 = u.getPassword();
		System.out.println(password1);
		String password2 = user.getPassword();
		System.out.println(password2);

		if(password1.equals(password2)) {


			return new ResponseEntity<User>(HttpStatus.NOT_ACCEPTABLE);  

		}

		u.setPassword(password2);

		User updateUsers = userService.save(u);
		return ResponseEntity.ok(updateUsers);
	}


	//update user by emailid 
	@RequestMapping(value="/updateuserbyemail/{emailid}",method=RequestMethod.PUT)
	public void updateUserbyEmail(@PathVariable String emailid, @RequestBody String password) {

		User obj = null;
		if(emailid != null) {
			obj = userService.fetchUserByEmailId(emailid);
			obj.setPassword(password);
		}

	}

	// To get user details by userid 
	@RequestMapping(value="/userbyuserid/{userid}",method=RequestMethod.GET)
	public User userDetailsById(@PathVariable Integer userid) {

		System.out.println("userService.getClass() : "+ userService.getClass());

		User user = userService.userDetailsById(userid);
		return user;


	}
	//get user by emailid 
	@RequestMapping(value="/userbyemail/{emailid}",method=RequestMethod.GET)
	public User getUserByEmailId(@PathVariable String emailid) {
		System.out.println("userService.getClass() : "+ userService.getClass());
		User user = userService.getUserByEmailId(emailid);
		return user;
	}
	//update user 
	@RequestMapping(value="/updateuser",method=RequestMethod.PUT)
	public User updateUser(@RequestBody User user ) {

		userService.updateUser(user);

		return user;
	}

	//find user by name 
	@RequestMapping(value="/userbyname/{username}",method=RequestMethod.GET)
	public User getUserByName(@PathVariable String username) {

		System.out.println("userService.getClass() : "+ userService.getClass());

		User user = userService.getUserByName(username);
		return user;


	}
	//user list 
	@RequestMapping( value="/userlist",method=RequestMethod.GET)
	public List<User> list() {
		return userService.list();

	}
	//find user by mobile number 
	@RequestMapping(value="/userbymobilenumber/{mobilenumber}",method=RequestMethod.GET)
	public User getUserByMobileNumber(@PathVariable String mobilenumber) {


		System.out.println("userService.getClass() : "+ userService.getClass());

		User user = userService.getUserByMobileNumber(mobilenumber);
		return user;


	}

	// delete user by id  
	@DeleteMapping("/user/{userid}")
	public ResponseEntity<Map<String, Boolean>> deleteUser(@PathVariable Integer userid) {
		User user = userService.findById(userid);

		userService.delete(user);
		Map<String,Boolean> response = new HashMap<>();
		response.put("deleted",Boolean.TRUE);
		return ResponseEntity.ok(response);

	}
	
	@PutMapping("/updateroles/{userid}/{roleid}")
	public ResponseEntity<User> updateRoles(@PathVariable Integer userid,@PathVariable Integer roleid, @RequestBody Role role) {
		User u = userService.getUsersById(userid);
		Role r = roleRepository.findRoleById(roleid);
		List<Role> roles = u.getRole();
		roles.set(0, r);
		u.setRole(roles);
		User updateRoles = userService.save(u);
		return ResponseEntity.ok(updateRoles);
	}

}