package com.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.Status;
import com.medicare.model.User;
import com.medicare.service.OrderService;

@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/orders/")
@RestController 
public class OrderController {

	@Autowired
	OrderService orderService;
	//add new order 
	@PostMapping("/add")
	public ResponseEntity<Orders> addOrder(@RequestBody Orders order){

		System.out.println("welcome to product controller ");
		return ResponseEntity.ok(orderService.addOrder(order));
	}

	//get all order list 
	@GetMapping("/orderlist")  
	private List<Orders> getAllOrders()   
	{  
		return orderService.getAllOrders();  
	}  
	//get order by id 

	@GetMapping("/orders/{id}")
	public ResponseEntity<Orders> getbyid(@PathVariable Integer id) {
		Orders orders = orderService.getById(id);

		return ResponseEntity.ok(orders);
	}
	//update orders by id  
	@PutMapping("/updateorders/{id}")
	public ResponseEntity<Orders> updateStatus(@PathVariable Integer id, @RequestBody Orders orders) {
		Orders o = orderService.getOrdersById(id);

		o.setStatus(orders.getStatus());

		Orders updateStatus = orderService.save(o);
		return ResponseEntity.ok(updateStatus);
	}
	//product list as descending order it return  List object  
	@GetMapping("/productlistdesc")  
	private List<Orders> getAllOrdersDesc(){  
		return orderService.getAllOrdersDesc();  
	}  
	//product list as descending order it return  List object  
		@GetMapping("/productlistdesc/{userid}")  
		private List<Orders> getAllOrderListByUserId(@PathVariable  Integer userid){  
			return orderService.getAllOrderListByUserId(userid);  
		}  
	
		
		


}