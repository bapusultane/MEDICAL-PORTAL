package com.medicare.controller;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medicare.model.Category;
import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.User;
import com.medicare.respository.ProductRepository;
import com.medicare.service.CategoryService;
import com.medicare.service.ProductService;
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/product/")
public class ProductController {


	@Autowired 
	ProductService productService;

	@Autowired 
	ProductRepository  productRepository;

	@Autowired
	CategoryService categoryService;
//add new product
	@PostMapping("/add")
	public ResponseEntity<Product> addProduct(@RequestBody Product product){

		String productName = product.getName();
		if(productName != null && !"".equals(productName)) {
			Product proObj = productService.findProductByName(productName);
			if(proObj != null) {
				return new ResponseEntity<Product>(HttpStatus.BAD_REQUEST);
			}
		}
		return productService.addProduct(product);
	}
	//To get all product list 
	@GetMapping("/productlist")  
	private List<Product> getAllProduct(){  
		return productService.getAllProduct();  
	}  

	//update product by id 
	@PutMapping("/product/{pid}")
	public ResponseEntity<Product> updateProduct(@PathVariable Integer pid, @RequestBody Product product) {
		Product p = productService.getProductById(pid);
//category come from id 
		p.setBrandtype(product.getBrandtype());
		p.setCategory(product.getCategory());
		
		p.setDescription(product.getDescription());
		p.setPrice(product.getPrice());
		p.setName(product.getName());
		p.setImageurl(product.getImageurl());
		p.setQuantity(product.getQuantity());



		Product updateProduct = productService.save(p);
		return ResponseEntity.ok(updateProduct);
	}



	//To get all product by category name 
	@GetMapping("/product/{catid}")  
	private List<Product> getAllProductByCategory(@PathVariable("catid") Integer catid){  
		return productService.getAllProductByCategory(catid);  
	}  

	@GetMapping("/prolist/{catid}")  
	private List<?> getAllProductByCategory1(@PathVariable ("catid") Integer catid){  
		return productService.getAllProductByCategory1(catid);  
	}  
	
	

	//To get all product by  name 
	@GetMapping("/productbyname/{name}")  
	private List<Product> getAllProductByName(@PathVariable("name") String name){  
		return productService.getAllProductByName(name);  
	}  

	// delete product by product id  
	@DeleteMapping("/product/{pid}")  
	private void deleteProduct(@PathVariable("pid") Integer pid)   
	{  
		productService.delete(pid); 
	}  
	//product by id

	@GetMapping("/products/{pid}")  
	private Product getProductById(@PathVariable("pid") Integer pid)   
	{  
		return productService.getProductById(pid); 
	}  

	//disable product by id 
	@PutMapping("/disableproduct/{pid}")
	public ResponseEntity<Product> disable(@PathVariable Integer pid, @RequestBody Product product) {
		Product p = productService.getProductById(pid);

		if(product.getStatus()==0) {
			p.setStatus(1);
		}
		else {
			p.setStatus(0);
		}

		Product disable = productService.save(p);
		return ResponseEntity.ok(disable);
	}

	//update product
	@PutMapping("/update")  
	private Product update(@RequestBody Product product)   
	{  
		productService.saveOrUpdate(product);  
		return product;  
	} 

	@PutMapping("/update/product/{catid}")
	private void updateProduct(@PathVariable("catid") Integer catid) {
		System.out.println("Category Id-"+catid);
		List<Product> product =  productService.getByCatId(catid);
		for(Object temp: product) {
			System.out.println("Product Data="+temp);
		}

	}


	@PutMapping("/updateproducts/{pid}")
	public ResponseEntity<Product> updateProduct1(@PathVariable Integer pid, @RequestBody Product product) {
		Product p = productService.getProductById(pid);

		p.setBrandtype(product.getBrandtype());
		p.setCategory(product.getCategory());
		p.setDescription(product.getDescription());
		p.setPrice(product.getPrice());
		p.setName(product.getName());
		p.setImageurl(product.getImageurl());
		p.setQuantity(product.getQuantity());


		Product updateProduct = productService.updateProduct1(p);
		return ResponseEntity.ok(updateProduct);
	}

	@PutMapping("/updates")
	public ResponseEntity<Product> updateProductBycatid(@RequestBody Product product) {
		Product p = productService.updateProductBycatid();


		return ResponseEntity.ok(p);
	}

	
	@PostMapping("/create/product/{catid}")
	public ResponseEntity<Product> createProduct(@RequestBody Product product, @PathVariable Integer catid){
		product = productService.createProductByCategory(product,catid);
		return new ResponseEntity<Product>(product,HttpStatus.CREATED);
	}
	

	
	
}







