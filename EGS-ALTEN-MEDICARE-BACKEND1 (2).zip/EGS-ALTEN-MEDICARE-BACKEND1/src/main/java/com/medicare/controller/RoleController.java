package com.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.model.Category;
import com.medicare.model.Product;
import com.medicare.model.Role;
import com.medicare.model.User;
import com.medicare.service.RoleService;
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/role/")
public class RoleController {
	@Autowired 
	RoleService roleService; 

//add new role
	@PostMapping("/add")
	public ResponseEntity<Role> addRole(@RequestBody Role role){
		String roleUser = role.getRoleName();
		if(roleUser != null && !"".equals(roleUser)) {
			Role Obj = roleService.fetchUserByRole(roleUser);
			if(Obj != null) {
				return new ResponseEntity<Role>(HttpStatus.BAD_REQUEST);
			}
		}
		return roleService.addRole(role);

	}
	//all user list
	@GetMapping("/rolelist")
	private List<Role> getAllRole(){
		return roleService.getAllRole();
	}
}





