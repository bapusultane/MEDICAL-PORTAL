package com.medicare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.model.Category;
import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.Status;
import com.medicare.service.StatusService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/status/")
public class StatusController {
	
	@Autowired
	StatusService statusService;
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Status> updateStatus(@PathVariable Integer id, @RequestBody Orders orders) {
		Status status1 = statusService.updateStatus(id,orders);
		return ResponseEntity.ok(status1);
	}
	
	
	

}
