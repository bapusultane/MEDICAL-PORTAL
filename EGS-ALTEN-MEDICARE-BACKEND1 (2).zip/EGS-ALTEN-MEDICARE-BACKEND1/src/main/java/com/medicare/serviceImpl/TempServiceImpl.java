package com.medicare.serviceImpl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.model.Temp;
import com.medicare.respository.ProductRepository;
import com.medicare.respository.TempRepository;
import com.medicare.service.ProductService;
import com.medicare.service.TempService;

@Service
public class TempServiceImpl implements TempService {

	@Autowired 
	TempRepository tempRepository;

	
	@Override
	public Temp addrecent(Temp temp) {
		
		Temp temp1 = new Temp();
		temp1.setPid(temp.getPid());
		temp1.setId(temp.getId());
		temp1.setUserid(temp.getUserid());
		
		temp = tempRepository.save(temp1);
		
		return temp;
	
	}

	@Override
	public List<?> getAllRecentDesc() {
		return tempRepository.getAllRecentDesc();
	}

}
