package com.medicare.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.Temp;
import com.medicare.respository.OrderRepository;
import com.medicare.respository.TempRepository;
import com.medicare.service.OrderService;
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired 
	OrderRepository ordersRepository;

	@Autowired
	TempRepository  tempRepository;
	//add 
	@Override
	public Orders addOrder(Orders orders) {
		//order obje
		Orders Oorders= ordersRepository.save(orders);
		for(int i=0;i<orders.getPid().size();i++) {
			Temp temp = new Temp();
			temp.setPid(orders.getPid().get(i));
			temp.setId(Oorders.getId());
			temp.setUserid(Oorders.getUserid());
			tempRepository.save(temp);
		}
		return Oorders;
	}

	@Override
	public List<Orders> getAllOrders() {

		return ordersRepository.findAll();
	}

	@Override
	public Orders getById(Integer id) {

		return  ordersRepository.getById(id);
	}

	@Override
	public Orders getStatusById(Integer id) {

		return ordersRepository.getStatusById(id);
	}

	@Override
	public Orders save(Orders oders) {

		return ordersRepository.save(oders);
	}

	@Override
	public Orders getOrdersById(Integer id) {

		return ordersRepository.getOrdersById(id);
	}

	@Override
	public List<Orders> getAllOrdersDesc() {

		return ordersRepository.getAllOrdersDesc();
	}

	@Override
	public List<Orders> getAllOrderListByUserId(Integer userid) {

		return ordersRepository.getAllOrderListByUserId(userid);
	}

}


