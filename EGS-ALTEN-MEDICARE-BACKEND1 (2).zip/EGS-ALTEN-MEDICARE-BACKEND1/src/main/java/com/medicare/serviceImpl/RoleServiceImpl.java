package com.medicare.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.medicare.model.Category;
import com.medicare.model.Product;
import com.medicare.model.Role;
import com.medicare.model.User;
import com.medicare.respository.RoleRepository;
import com.medicare.respository.UserRepository;
import com.medicare.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {
	@Autowired 
	RoleRepository roleRepository;

	@Override
	public Role fetchUserByRole(String userRole) {
		
		return roleRepository.fetchUserByRole(userRole);
	}

	@Override
	public ResponseEntity<Role> addRole(Role role) {
		Role Obj = roleRepository.save(role);
		return ResponseEntity.ok(Obj);

		
	}

	@Override
	public List<Role> getAllRole() {
		
		return roleRepository.findAll();
	}

	

	
	}


