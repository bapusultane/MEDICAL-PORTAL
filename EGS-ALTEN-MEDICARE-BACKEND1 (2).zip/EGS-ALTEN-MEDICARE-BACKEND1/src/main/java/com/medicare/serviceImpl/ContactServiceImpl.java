package com.medicare.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.medicare.model.Contact;
import com.medicare.respository.ContactRepository;
import com.medicare.service.ContactService;
@Service
public class ContactServiceImpl implements ContactService{

	@Autowired 
	ContactRepository contactRepository;

	@Override
	public ResponseEntity<Contact> addContact(Contact contact) {
		Contact con = contactRepository.save(contact);
		return ResponseEntity.ok(con);

	}

	@Override
	public List<Contact> getAllContacts() {
		
		return contactRepository.findAll();
	}

}
