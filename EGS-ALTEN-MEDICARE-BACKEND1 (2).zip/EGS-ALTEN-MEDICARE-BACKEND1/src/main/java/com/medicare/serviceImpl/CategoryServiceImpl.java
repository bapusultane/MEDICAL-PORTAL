package com.medicare.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.medicare.model.Category;
import com.medicare.model.Product;
import com.medicare.model.User;
import com.medicare.respository.CategoryRepository;
import com.medicare.respository.ProductRepository;
import com.medicare.service.CategoryService;
@Service
public class CategoryServiceImpl  implements CategoryService{

	@Autowired 
	CategoryRepository categoryRepository;

	@Autowired
	ProductRepository productRepository;
	//save category 
	@Override
	public Category save(Category category) {

		return categoryRepository.save(category);
	}
	//update category 
	@Override
	public void udpateCategory(Category category) {
		categoryRepository.save(category);
	}
	//category list 
	@Override
	public List<Category> getAllCategory() {

		return categoryRepository.findAll();
	}
	//delete category 
	@Override
	public void delete(Integer catid) {
		categoryRepository.deleteById(catid);
	}


	//get category by category id  
	@Override
	public Category getCategoryById(Integer catid) {

		return categoryRepository.getCategoryById(catid);
	}

	@Override
	public Category getCategoriesById(Integer catid) {

		return categoryRepository.getCategoriesById(catid);
	}
	//get category by categoryName 
	@Override
	public Category fetchCategoryByName(String categoryName) {
		return categoryRepository.findbyCategory(categoryName);
	}
	//add category service implements  
	@Override
	public ResponseEntity<Category> addCategory(Category category) {
		Category catObj = categoryRepository.save(category);
		return ResponseEntity.ok(catObj);
	}
	@Override
	public Category udpateCategory(Integer catid,Product product) {
		Category cat = categoryRepository.findById(catid).get();
		Product prod = productRepository.findById(catid).get();
		List<Product> pro = productRepository.findByIdCpfk(catid);
		System.out.println(pro);
		//List <Product> pro = cat.getProduct();
		//pro.add(product);
		//cat.setProduct(pro);
		prod.setCategory(product.getCategory());
		//cat.setCategory(product.getCategory());


		return categoryRepository.save(cat);
	}


}
