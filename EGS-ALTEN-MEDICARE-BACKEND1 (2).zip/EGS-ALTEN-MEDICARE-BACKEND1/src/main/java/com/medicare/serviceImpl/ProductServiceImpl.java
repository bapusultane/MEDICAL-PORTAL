package com.medicare.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.medicare.model.Category;
import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.User;
import com.medicare.respository.CategoryRepository;
import com.medicare.respository.ProductRepository;
import com.medicare.service.ProductService;


@Service
public class ProductServiceImpl implements ProductService{
	@Autowired 
	ProductRepository productRepository;

	@Autowired
	CategoryRepository categoryRepository;


	@Override
	public List<Product> getAllProduct() {

		return productRepository.findAll();
	}




	@Override
	public void deleteProduct(Integer pid) {
		productRepository.deleteById(pid);

	}
	public void saveOrUpdate(Product Product)   
	{  
		productRepository.save(Product);  
	} 

	@Override
	public List<Product> list() {
		return productRepository.findAll();
	}
	


	@Override
	public Product save(Product product) {

		return productRepository.save(product);
	}



	public List<Product> getAllProducts()   
	{  
		List<Product> Product = new ArrayList<Product>();  
		productRepository.findAll().forEach(Product1 -> Product.add(Product1));  
		return Product;  
	}  

	public void delete(Integer pid)   
	{  
		productRepository.deleteById(pid);  
	}  
	//updating a record  
	public void update(Product Product, Integer pid)   
	{  
		productRepository.save(Product);  

	}
	@Override
	public Product createProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void deleteProductById(Integer id) {
		// TODO Auto-generated method stub

	}
	@Override
	public Product getProductDetailsById(Integer id) {
		return productRepository.getProductDetailsById(id);
	}
	
	@Override
	public Product updateProductById(Integer pid) {
		Product pro = productRepository.updateProductById(pid);
		return productRepository.save(pro);
	}

	@Override
	public Product getProductById(Integer pid) {

		//return productRepository.getProductById(pid).get();
		return productRepository.findById(pid).get();
	}
	@Override
	public Product productsByName(String category) {

		return productRepository.productsByName(category);
	}
	@Override
	public List<Product> getAllProductByCategory(Integer catid) {

		return productRepository.getAllProductByCategory(catid);
	}

	@Override
	public List<Product> getAllProductByName(String name) {

		return productRepository.getAllProductByName(name);
	}
	@Override
	public List<Product> disable(Integer status) {

		return productRepository.disable(status);
	}

	@Override
	public Product findProductByName(String productName) {

		return productRepository.findProductByName(productName);
	}
	@Override
	public List<Product> getByCatId(Integer catid) {

		return productRepository.getByCatId(catid);
	}
	@Override
	public Product updateProduct1(Product p) {

		return productRepository.updateProduct1(p);
	}
	@Override
	public Product updateProductBycatid() {

		return productRepository.updateProductBycatid();
	}




	@Override
	public ResponseEntity<Product> addProduct(Product product) {
		Product proObj = productRepository.save(product);
		return ResponseEntity.ok(proObj);
	}




	@Override
	public Product createProductByCategory(Product product, Integer catid) {
		Category cat = this.categoryRepository.findById(catid).orElseThrow();
		product.setBrandtype(product.getBrandtype());
		product.setDescription(product.getDescription());
		product.setImageurl(product.getImageurl());
		product.setName(product.getName());
		product.setPrice(product.getPrice());
		product.setQuantity(product.getQuantity());
		product.setStatus(product.getStatus());
		product.setCategory(cat);
		Product pro = this.productRepository.save(product);
		return pro;
	}



	@Override
	public Product updateProduct(Product product, Integer pid) {
		productRepository.findById(pid);
		return productRepository.save(product);

	}



	@Override
	public List<?> getAllProductByCategory1(Integer catid) {
		
		return productRepository.getAllProductByCategory1(catid);
	}


	 @Override
	  public ResponseEntity<Product> updateMovie(Integer id, Product product) {
	    if (productRepository.findById(id).isPresent()) {

	      Category cat = categoryRepository.findCategoryByCatId(product.getCategory());
	      Product pro = productRepository.findById(id).get();
	     
	      pro.setCategory(cat);
	      pro.setBrandtype(product.getBrandtype());
	      pro.setName(product.getName());
	      pro.setImageurl(product.getImageurl());
	      pro.setPrice(product.getPrice());
	      pro.setQuantity(product.getQuantity());
	      pro.setDescription(product.getDescription());
	    
	     
	      Product pro2 = productRepository.save(pro);
	      return ResponseEntity.ok(pro2);
	    } else {
	      return new ResponseEntity<Product>(HttpStatus.BAD_REQUEST);
	    }

	  }




}
