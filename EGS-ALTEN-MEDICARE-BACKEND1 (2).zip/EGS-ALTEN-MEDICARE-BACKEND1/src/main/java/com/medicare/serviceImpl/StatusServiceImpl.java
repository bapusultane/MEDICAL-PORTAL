package com.medicare.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.model.Category;
import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.Status;
import com.medicare.respository.OrderRepository;
import com.medicare.respository.StatusRepository;
import com.medicare.service.StatusService;

@Service
public class StatusServiceImpl implements  StatusService{
	@Autowired
	StatusRepository statusRepository;
	@Autowired
	OrderRepository  OrdersRepository;

	@Override
	public Status updateStatus(Integer id, Orders orders) {

		Status sts = statusRepository.findById(id).get();
		Orders order = OrdersRepository.findById(id).get();
		List<Orders> orde = OrdersRepository.findByIdStatusId(id);
		System.out.println(orde);
		//List <Product> pro = cat.getProduct();
		//pro.add(product);
		//cat.setProduct(pro);
		order.setStatus(orders.getStatus());
		//cat.setCategory(product.getCategory());


		return statusRepository.save(sts);
	}

}


