package com.medicare.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.medicare.model.Role;
import com.medicare.model.User;
import com.medicare.respository.RoleRepository;
import com.medicare.respository.UserRepository;
import com.medicare.service.UserService;

@Service
public class UserServiceImpl  implements UserService {
	@Autowired
	UserRepository userRepository;


	@Autowired
	RoleRepository roleRepository;

	@Override
	public User getUserByName(String username) {
		return userRepository.getUserByName(username);


	}

	@Override
	public List<User> list() {

		return userRepository.findAll();
	}

	@Override
	public User getUserDetailsByUsernameAndPassword(String username, String password) {

		return userRepository.getUserDetailsByUsernameAndPassword(username, password);
	}

	@Override
	public User getUserByMobileNumber(String mobilenumber) {

		return userRepository.getUserByMobileNumber(mobilenumber);
	}

	@Override
	public void updateUser(User user) {
		userRepository.save(user);
	}

	@Override
	public User save(User user) {
		return userRepository.save(user);
	}

	@Override
	public User findById(Integer userid) {
		return userRepository.findById(userid).orElse(new User());
	}

	@Override 
	public void delete(User user) {
		userRepository.delete(user);
	}

	@Override
	public User existsByUsername(String name) {

		return userRepository.existsByUsername(name);
	}

	@Override
	public User getUserByRole(String role) {

		return userRepository.getUserByRole(role);
	}

	@Override
	public User signUp(User user) {

		return userRepository.save(user);
	}

	@Override
	public User saveUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public User fetchUserByEmailId(String emailid) {
		return userRepository.findbyEmailId(emailid);
	}




	@Override
	public User getUserByemailId(String emailid) {

		return userRepository.getUserByemailId(emailid);

	}

	@Override
	public User getUserByEmailId(String emailid) {

		return userRepository.getUserByEmailId(emailid);
	}

	@Override
	public User fetchUsersByEmailAndPasswordAndRole(String emailId, String password) {

		return userRepository.fetchUsersByEmailAndPasswordAndRole(emailId, password);
	}

	@Override
	public User userDetailsById(Integer userid) {

		return userRepository.userDetailsById(userid);
	}

	@Override
	public User register(User user) {

		user.setAddress(user.getAddress());
		user.setDob(user.getDob());
		user.setEmailid(user.getEmailid());
		user.setMobilenumber(user.getMobilenumber());
		user.setPassword(user.getPassword());
		user.setUsername(user.getUsername());
		List<Role> roles = new ArrayList<>();
		roles.add(roleRepository.findByName("USER"));
		user.setRole(roles);
		return userRepository.save(user);

	}
	@Override
	public User getUsersById(Integer userid) {
		
		return userRepository.getUsersById(userid);
	}


}

