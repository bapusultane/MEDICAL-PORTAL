package com.medicare.service;


import java.util.List;

import org.springframework.http.ResponseEntity;

import com.medicare.model.Product;
import com.medicare.model.Role;
import com.medicare.model.User;

public interface RoleService {

	Role fetchUserByRole(String userRole);

	ResponseEntity<Role> addRole(Role role);
	
	List<Role> getAllRole();

}
