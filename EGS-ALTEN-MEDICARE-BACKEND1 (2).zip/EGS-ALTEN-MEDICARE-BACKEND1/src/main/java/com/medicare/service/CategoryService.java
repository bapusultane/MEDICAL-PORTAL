package com.medicare.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.medicare.model.Category;
import com.medicare.model.Product;



public interface CategoryService {

	Category save(Category category);

	void udpateCategory(Category category);

	List <Category> getAllCategory();

	void delete(Integer catid);

	Category getCategoryById(Integer catid);

	Category getCategoriesById(Integer catid);

	Category fetchCategoryByName(String categoryName);

	ResponseEntity<Category> addCategory(Category category);
	
	Category udpateCategory(Integer catid,Product product);



	

	
}
