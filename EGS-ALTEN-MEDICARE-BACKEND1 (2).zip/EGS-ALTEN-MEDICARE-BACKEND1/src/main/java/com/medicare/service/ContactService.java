package com.medicare.service;

import java.util.List;

import org.springframework.http.ResponseEntity;


import com.medicare.model.Contact;

public interface ContactService {

	

	ResponseEntity<Contact> addContact(Contact contact);

	List<Contact> getAllContacts();

}
