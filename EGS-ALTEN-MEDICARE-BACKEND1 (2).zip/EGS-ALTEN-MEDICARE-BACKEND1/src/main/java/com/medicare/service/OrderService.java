package com.medicare.service;

import java.util.List;

import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.Temp;

public interface OrderService {

	List<Orders> getAllOrders();

	Orders addOrder(Orders orders);

	Orders  getById(Integer id);

	Orders getStatusById(Integer id);

	Orders save(Orders oders);

	Orders getOrdersById(Integer id);

	List<Orders> getAllOrdersDesc();

	List<Orders> getAllOrderListByUserId(Integer userid);

	
	
	
	
}
