package com.medicare.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.medicare.model.Orders;
import com.medicare.model.Product;
import com.medicare.model.User;


public interface ProductService {
	

	Product getProductDetailsById(Integer id);

	Product updateProductById(Integer id);

	void deleteProductById(Integer id);

	List<Product> list();

	
	Product save(Product product);


	Product createProduct(Product product);

	List<Product> getAllProduct();


	void delete(Integer pid);

	void saveOrUpdate(Product product);

	List<Product> getAllProducts();

	ResponseEntity<Product> addProduct(Product product);

	void deleteProduct(Integer pid );

	Product updateProduct(Product product,Integer pid);

	Product getProductById (Integer pid);

	Product productsByName(String name);

	List<Product> getAllProductByCategory(Integer catid);

	List<Product> getAllProductByName(String name);

	List<Product> disable(Integer status);

	Product findProductByName(String productName);

	List<Product> getByCatId(Integer catid);

	Product updateProduct1(Product p);

	Product updateProductBycatid();

	Product createProductByCategory(Product product, Integer catid);


	List<?> getAllProductByCategory1(Integer catid);

	ResponseEntity<Product> updateMovie(Integer pid, Product product);

	
	

}
