package com.medicare.service;

import java.util.List;
import java.util.Map;

import com.medicare.model.Temp;

public interface TempService {

	Temp addrecent(Temp temp);

	List<?> getAllRecentDesc();


}
