package com.medicare.service;

import com.medicare.model.Orders;
import com.medicare.model.Status;

public interface StatusService {

	Status updateStatus(Integer status, Orders orders);

	
}
