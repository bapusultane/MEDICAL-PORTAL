package com.medicare.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.medicare.model.User;



public interface UserService {

	User getUserByName(String name );

	void updateUser(User user);

	List<User> list();

	User getUserDetailsByUsernameAndPassword(String username,String password); 

	User getUserByMobileNumber(String mobilenumber);

	User save(User user);

	User findById(Integer id );

	void delete(User user);

	User existsByUsername (String name);

	User getUserByRole(String role);

	User signUp(User user);

	User saveUser(User user);

	User fetchUserByEmailId(String emailid);



	User getUserByemailId(String emailid);

	User getUserByEmailId(String emailid);

	User fetchUsersByEmailAndPasswordAndRole(String emailId, String password);

	User userDetailsById(Integer userid);
	
	User register(User user);

	User getUsersById(Integer userid);

}

