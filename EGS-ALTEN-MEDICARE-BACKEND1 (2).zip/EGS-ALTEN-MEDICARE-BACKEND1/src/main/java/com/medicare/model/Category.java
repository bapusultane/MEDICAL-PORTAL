package com.medicare.model;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;


@Entity
@Table(name="category")
public class Category {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer catid;
	@Column(unique = true)
	private String category;
	private  String imageurl;
	//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToMany(mappedBy="category", fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JsonIgnore
	private Set<Product> prdouct;

	public Integer getCatid() {
		return catid;
	}

	public void setCatid(Integer catid) {
		this.catid = catid;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getImageurl() {
		return imageurl;
	}

	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}

	public Set<Product> getPrdouct() {
		return prdouct;
	}

	public void setPrdouct(Set<Product> prdouct) {
		this.prdouct = prdouct;
	}

	public Category(Integer catid) {
		this.catid = catid;
	}

	public Category() {
		super();
	}

	public Category(Integer catid, String category, String imageurl, Set<Product> prdouct) {
		this.catid = catid;
		this.category = category;
		this.imageurl = imageurl;
		this.prdouct = prdouct;
	}

	@Override
	public String toString() {
		return "Category [catid=" + catid + ", category=" + category + ", imageurl=" + imageurl + ", prdouct=" + prdouct
				+ "]";
	}

	
}