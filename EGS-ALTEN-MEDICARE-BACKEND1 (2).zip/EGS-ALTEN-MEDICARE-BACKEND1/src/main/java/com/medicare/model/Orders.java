package com.medicare.model;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
@Entity
@Table(name="orders")
public class Orders {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	@ManyToOne(fetch=FetchType.EAGER)
	//@JsonIgnore
	private Status status;
	private Integer userid;
	private Integer totalitem;
	private long totalprice;
	private String name;
	//integer array pid
	private List <Integer> pid;
	private String paymentmode;
	//@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date orderdate;
	@PrePersist
	private void onCreate() {
		orderdate= new Date();
	}	 

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public Integer getUserid() {

		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public Integer getTotalitem() {
		return totalitem;
	}
	public void setTotalitem(Integer totalitem) {
		this.totalitem = totalitem;
	}
	public long getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(long totalprice) {
		this.totalprice = totalprice;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Integer> getPid() {
		return pid;
	}
	public void setPid(List<Integer> pid) {
		this.pid = pid;
	}
	public String getPaymentmode() {
		return paymentmode;
	}
	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}
	public Date getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}


	public Orders(Integer id, Status status, Integer userid, Integer totalitem, long totalprice, String name,
			List<Integer> pid, String paymentmode, Date orderdate) {
		super();
		this.id = id;
		this.status = status;
		this.userid = userid;
		this.totalitem = totalitem;
		this.totalprice = totalprice;
		this.name = name;
		this.pid = pid;
		this.paymentmode = paymentmode;
		this.orderdate = orderdate;
	}

	public Orders() {

	}

}
